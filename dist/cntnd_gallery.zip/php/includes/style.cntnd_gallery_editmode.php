<style>
<?= file_get_contents($cfgClient[$client]["module"]["path"].'cntnd_gallery/css/cntnd_gallery.css') ?>
</style>
